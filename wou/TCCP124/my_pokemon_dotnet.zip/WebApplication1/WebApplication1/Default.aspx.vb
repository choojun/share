﻿Public Class _Default
    Inherits Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim collectedType As String = ""
        For i As Integer = 0 To lstType.Items.Count - 1
            If lstType.Items(i).Selected Then
                If collectedType.Length = 0 Then
                    collectedType = lstType.Items(i).ToString()
                ElseIf collectedType.Length > 0 Then
                    collectedType = collectedType & " and " & lstType.Items(i).ToString()
                End If
            End If
        Next

        ' create dictionary of parameters for inserting
        Dim insertParameters As New ListDictionary()
        'insertParameters.Add("Date", Date.Now.ToShortDateString())
        insertParameters.Add("Date", calDate.SelectedDate & "")
        insertParameters.Add("Name", txtName.Text)
        insertParameters.Add("Type", collectedType)
        insertParameters.Add("Species", cboSpecies.SelectedValue)
        insertParameters.Add("Ability", cboAbility.SelectedValue)
        ' execute an INSERT LINQ statement to add a new entry
        LinqDataSource1.Insert(insertParameters)

        ' clear the user's inputs
        txtName.Text = String.Empty
        lstType.ClearSelection()
        cboSpecies.ClearSelection()
        cboAbility.ClearSelection()


        ' update the GridView with the new database table contents
        GridView1.DataBind()
    End Sub

    Protected Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' clear the user's inputs
        txtName.Text = String.Empty
        lstType.ClearSelection()
        cboSpecies.ClearSelection()
        cboAbility.ClearSelection()
    End Sub
End Class