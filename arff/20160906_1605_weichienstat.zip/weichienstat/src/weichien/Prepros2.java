package weichien;

import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import au.com.bytecode.opencsv.CSVReader;

public class Prepros2
{

	public static void main(String[] args) throws IOException, ParseException

	{

		Prepros2 myObj = new Prepros2();

		myObj.doIt();

		// System.out.println(myObj.data2);

		myObj.doIt2();

		myObj.doIt3();

	}

	List<String> data0 = new ArrayList<String>(); // REQUESTOR

	List<String> data_down = new ArrayList<String>();

	List<String> data_solv = new ArrayList<String>();

	List<String> data1 = new ArrayList<String>(); // DATE_CLOSE

	List<String> data3 = new ArrayList<String>(); // DATE_ATND

	List<String> data4 = new ArrayList<String>(); // DATE_RQS

	List<String> data2 = new ArrayList<String>(); // NICKNAME

	List<String> data5 = new ArrayList<String>(); // PROBLEM

	List<String> data6 = new ArrayList<String>(); // CAUSE

	public void doIt3()

	{

		HashSet<String> set1 = new LinkedHashSet<String>();

		HashSet<String> set2 = new LinkedHashSet<String>();

		HashSet<String> set3 = new LinkedHashSet<String>();

		String output = "";

		for (int i = 0; i < data1.size(); i++)

		{

			output += data0.get(i) + "," + data2.get(i) + "," + data_down.get(i) + ","

					+ data_solv.get(i) + "," + data5.get(i) + "," + data6.get(i) + "\n";

			if (!set1.contains(data2.get(i)))

				set1.add(data2.get(i));

			if (!set2.contains(data5.get(i)))

				set2.add(data5.get(i));

			if (!set3.contains(data6.get(i)))

				set3.add(data6.get(i));

		}

		System.out.println("@relation production-data");

		System.out.println("@attribute REQUESTOR numeric");

		System.out.println("@attribute NICKNAME {" + unique(set1) + "}");

		System.out.println("@attribute DOWNTIME numeric");

		System.out.println("@attribute SOLVTIME numeric");

		System.out.println("@attribute PROBLEM {" + unique(set2) + "}");

		System.out.println("@attribute CAUSE {" + unique(set3) + "}");

		System.out.println("@data");

		System.out.println(output);

	}

	private String unique(Set<String> input)

	{

		String output2 = "";

		Iterator<String> it1 = input.iterator();

		while (it1.hasNext())

		{

			String aa = it1.next();

			output2 += aa + ",";

		}

		output2.substring(0, output2.length() - 1);

		return output2;

	}

	public void doIt2() throws IOException, ParseException

	{

		for (int i = 0; i < data1.size(); i++)

		{

			Date date1 = findDate(data1.get(i));

			SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd H:mm");

			// System.out.println("data1: "+date1+">>>"+dt1.format(date1));

			Date date4 = findDate(data4.get(i));

			// System.out.println("data4: "+date4+">>>"+dt1.format(date4));

			long a = date1.getTime() - date4.getTime();

			Date newDate = new Date(a);

			// System.out.println("\t"+newDate.getTime());

			data_down.add(a + "");

			Date date3 = findDate(data3.get(i));

			// System.out.println("data3: "+date3+">>>"+dt1.format(date3));

			long b = date1.getTime() - date3.getTime();

			Date newDate2 = new Date(b);

			// System.out.println("\t"+newDate2.getTime());

			data_solv.add(b + "");

		}

	}

	private Date findDate(String input) throws ParseException

	{

		String date_s = input;

		SimpleDateFormat dt = new SimpleDateFormat("MM/d/yyyy H:mm");

		Date date = dt.parse(date_s);

		SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd H:mm");

		return date;

	}

	public void doIt() throws IOException

	{

		int count = 0;

		List<String> code = null;

		List<String> name = null;

		String[] nextTrueLine = null;

		CSVReader reader = new CSVReader(new FileReader("data/08252016.csv"),

				',');

		while ((nextTrueLine = reader.readNext()) != null)

		{

			for (int i = 0; i < nextTrueLine.length; i++)

			{

				String bb = nextTrueLine[i].trim();

				if (i == 0) // requestor

					data0.add(bb);

				else if (i == 1)

					data1.add(bb);

				else if (i == 2)

				{

					String aa22 = bb;

					System.out.println("==t==" + aa22);

					data2.add(aa22);// .replace("#", "_"));

				}

				else if (i == 3)

					data3.add(bb);

				else if (i == 4)

					data4.add(bb);

				else if (i == 5)

					data5.add(bb.replace(" ", "_"));

				else if (i == 6)

				{

					String aa = bb.replace(" ", "_");

					// aa = aa.replace("/", "_");

					// aa = aa.replace("(", "_");

					// aa = aa.replace(")", "_");

					// System.out.println("==t=="+aa);

					if (aa.equalsIgnoreCase("hang"))

						aa = "1";

					else if (aa.equalsIgnoreCase("path_loss_out"))

						aa = "2";

					else

						aa = "3";

					// System.out.println("\t==t enhanced=="+aa);

					data6.add(aa);

				}

			}

		}

		reader.close();

		reader = null;

	}

}
