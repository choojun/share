package weichien;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Random;

import weka.clusterers.ClusterEvaluation;
import weka.clusterers.SimpleKMeans;
import weka.core.Instances;

public class ClusteringExp
{




	public static void main(String[] args) throws Exception
	{
		ClusteringExp m = new ClusteringExp();
		m.scenarioSanmina();
	}


	private int seedNum = 0;


	public void scenarioSanmina() throws Exception
	{

		Random rd = new Random (System.currentTimeMillis());
		seedNum = rd.nextInt();
		
		//hey wei chien!
		
		Prepros4 myObj = new Prepros4();
		myObj.doIt("data2/Sample master data_3.csv");
		myObj.normalizeData();
		String filename = "log/withoutclass"+System.currentTimeMillis()+".arff";
		myObj.prepareARFF_without_class(filename);
		
		System.out.println("Using seed number "+ seedNum);
		clusterTraining(filename);
		
		
	}

	public void clusterTraining(String fileName) throws Exception
	{
		// load data
		Instances data = new Instances(new BufferedReader(new FileReader(
				fileName)));

		Instances dataClusterer = data;
		

		// train clusterer
		SimpleKMeans clusterer = new SimpleKMeans();
		//EM clusterer = new EM();
		//FarthestFirst clusterer = new FarthestFirst();
		clusterer.setSeed(seedNum);
		//clusterer.setPreserveInstancesOrder(true);
		clusterer.setNumClusters(4);
		clusterer.setMaxIterations(100000);
		clusterer.buildClusterer(dataClusterer);

		// evaluate clusterer
		ClusterEvaluation ce = new ClusterEvaluation();
		ce.setClusterer(clusterer);
		ce.evaluateClusterer(data);
		// eval.crossValidateModel(
		// clusterer, data, 10, data.getRandomNumberGenerator(123));

		// print results
		System.out.println(ce.clusterResultsToString());
	}

	

}

