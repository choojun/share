package weichien;

import java.math.BigDecimal;
import java.math.MathContext;

public class WekaResult
{
	// for moea use
	public double tp = Double.NaN;
	public double tn = Double.NaN;
	public double fp = Double.NaN;
	public double fn = Double.NaN;
	
	public WekaResult(double tp, double tn, double fp, double fn)
	{
		this.tp = tp;
		this.tn = tn;
		this.fp = fp;
		this.fn = fn;
	}
	
	public double accuracy()
	{
		BigDecimal bd = new BigDecimal(tp + "");
		BigDecimal bd2 = new BigDecimal(tn + "");
		BigDecimal bd3 = new BigDecimal(fp + "");
		BigDecimal bd4 = new BigDecimal(fn + "");

		bd = bd.add(bd2);
		bd3 = bd3.add(bd4);
		bd3 = bd3.add(bd);
		bd = bd.divide(bd3, MathContext.DECIMAL64);
		double result = bd.doubleValue();
		bd = null;
		bd2 = null;
		bd3 = null;
		bd4 = null;
		return result;
	}

	public double sensitivity()
	{
		BigDecimal bd = new BigDecimal(tp + "");
		BigDecimal bd2 = new BigDecimal(fn + "");
		bd2 = bd2.add(bd);
		bd = bd.divide(bd2, MathContext.DECIMAL64);
		double result = bd.doubleValue();
		bd = null;
		bd2 = null;
		return result;
	}

	public double specificity()
	{
		BigDecimal bd = new BigDecimal(tn + "");
		BigDecimal bd2 = new BigDecimal(fp + "");
		bd2 = bd2.add(bd);
		bd = bd.divide(bd2, MathContext.DECIMAL64);
		double result = bd.doubleValue();
		bd = null;
		bd2 = null;
		return result;
	}
}
