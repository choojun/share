package weichien;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import au.com.bytecode.opencsv.CSVReader;

public class Prepros3
{

	public static void main(String[] args) throws IOException, ParseException

	{
		Prepros3 myObj = new Prepros3();
		myObj.doIt("data2/Sample master data_1.csv");
		myObj.normalizeData();
		String filename = "log/"+System.currentTimeMillis()+".arff";
		//myObj.prepareARFF_without_class(filename);
		myObj.prepareARFF_with_class(filename);
	}

	
	List<String> data_down = new ArrayList<String>();
	List<String> data_solv = new ArrayList<String>();


	public void prepareARFF_with_class(String filename)
	{
		
		System.out.println("data0: "+data0.size()+ ">>>"+data0);
		System.out.println("data1: "+data1.size()+ ">>>"+data1);
		System.out.println("data2: "+data2.size()+ ">>>"+data2);
		System.out.println("data3: "+data3.size()+ ">>>"+data3);
		System.out.println("data4: "+data4.size()+ ">>>"+data4);
		System.out.println("data5: "+data5.size()+ ">>>"+data5);
		System.out.println("data6: "+data6.size()+ ">>>"+data6);
		System.out.println("data7: "+data7.size()+ ">>>"+data7);
		System.out.println("data8: "+data8.size()+ ">>>"+data8);
		System.out.println("");
		System.out.println("data0Bound: "+data0Bound[0]+ " & "+ data0Bound[1]);
		System.out.println("data1Bound: "+data1Bound[0]+ " & "+ data1Bound[1]);
		System.out.println("data2Bound: "+data2Bound[0]+ " & "+ data2Bound[1]);
		System.out.println("data3Bound: "+data3Bound[0]+ " & "+ data3Bound[1]);
		System.out.println("data4Bound: "+data4Bound[0]+ " & "+ data4Bound[1]);
		System.out.println("data5Bound: "+data5Bound[0]+ " & "+ data5Bound[1]);
		System.out.println("data6Bound: "+data6Bound[0]+ " & "+ data6Bound[1]);
		System.out.println("data7Bound: "+data7Bound[0]+ " & "+ data7Bound[1]);
		System.out.println("data8Bound: "+data8Bound[0]+ " & "+ data8Bound[1]);
		System.out.println("");
		System.out.println("data0Normalized: "+data0Normalized.size()+ ">>>"+data0Normalized);
		System.out.println("data1Normalized: "+data1Normalized.size()+ ">>>"+data1Normalized);
		System.out.println("data2Normalized: "+data2Normalized.size()+ ">>>"+data2Normalized);
		System.out.println("data3Normalized: "+data3Normalized.size()+ ">>>"+data3Normalized);
		System.out.println("data4Normalized: "+data4Normalized.size()+ ">>>"+data4Normalized);
		System.out.println("data5Normalized: "+data5Normalized.size()+ ">>>"+data5Normalized);
		System.out.println("data6Normalized: "+data6Normalized.size()+ ">>>"+data6Normalized);
		System.out.println("data7Normalized: "+data7Normalized.size()+ ">>>"+data7Normalized);
		System.out.println("data8Normalized: "+data8Normalized.size()+ ">>>"+data8Normalized);
		System.out.println("");
		String output = "";
		for (int i = 0; i < data0Normalized.size(); i++)
		{
			output += data0Normalized.get(i) + "," + data1Normalized.get(i) + "," 
					+ data2Normalized.get(i) + "," + data3Normalized.get(i) + ","
					+ data4Normalized.get(i) + "," + data5Normalized.get(i) + ","
					+ data7Normalized.get(i) + "," + data8Normalized.get(i) + ","
					+ data6Normalized.get(i)
					+ "\n";

		}
		
		String uniqueProblemString = "";
		for (double s : uniqueProblem) 
		{
			uniqueProblemString += s + ",";
		}
		uniqueProblemString = uniqueProblemString.substring(0, uniqueProblemString.length()-1);

		String output2 = "";
		output2 += "@relation production-data";
		output2 += "\n";
		output2 += "@attribute requestor_nationality numeric";
		output2 += "\n";
		output2 += "@attribute requestor_gender numeric";
		output2 += "\n";
		output2 += "@attribute no_of_respondent numeric";
		output2 += "\n";
		output2 += "@attribute respondent_nationality numeric";
		output2 += "\n";
		output2 += "@attribute shift numeric";
		output2 += "\n";
		output2 += "@attribute nickname_type numeric";
		output2 += "\n";
		output2 += "@attribute downtime numeric";
		output2 += "\n";
		output2 += "@attribute solvetime numeric";
		output2 += "\n";
		output2 += "@attribute CLASS {" + uniqueProblemString + "}"; // problem
		output2 += "\n";
		output2 += "@data";
		output2 += "\n";

		System.out.println(output2 + output);
		
		FileWriter fw = null;
		try
		{
			fw = new FileWriter(filename, false);
			fw.write(output2);
			fw.write(output);
			fw.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		fw = null;
		
		

	}
	
	public void prepareARFF_without_class(String filename)
	{
		
		System.out.println("data0: "+data0.size()+ ">>>"+data0);
		System.out.println("data1: "+data1.size()+ ">>>"+data1);
		System.out.println("data2: "+data2.size()+ ">>>"+data2);
		System.out.println("data3: "+data3.size()+ ">>>"+data3);
		System.out.println("data4: "+data4.size()+ ">>>"+data4);
		System.out.println("data5: "+data5.size()+ ">>>"+data5);
		System.out.println("data6: "+data6.size()+ ">>>"+data6);
		System.out.println("data7: "+data7.size()+ ">>>"+data7);
		System.out.println("data8: "+data8.size()+ ">>>"+data8);
		System.out.println("");
		System.out.println("data0Bound: "+data0Bound[0]+ " & "+ data0Bound[1]);
		System.out.println("data1Bound: "+data1Bound[0]+ " & "+ data1Bound[1]);
		System.out.println("data2Bound: "+data2Bound[0]+ " & "+ data2Bound[1]);
		System.out.println("data3Bound: "+data3Bound[0]+ " & "+ data3Bound[1]);
		System.out.println("data4Bound: "+data4Bound[0]+ " & "+ data4Bound[1]);
		System.out.println("data5Bound: "+data5Bound[0]+ " & "+ data5Bound[1]);
		System.out.println("data6Bound: "+data6Bound[0]+ " & "+ data6Bound[1]);
		System.out.println("data7Bound: "+data7Bound[0]+ " & "+ data7Bound[1]);
		System.out.println("data8Bound: "+data8Bound[0]+ " & "+ data8Bound[1]);
		System.out.println("");
		System.out.println("data0Normalized: "+data0Normalized.size()+ ">>>"+data0Normalized);
		System.out.println("data1Normalized: "+data1Normalized.size()+ ">>>"+data1Normalized);
		System.out.println("data2Normalized: "+data2Normalized.size()+ ">>>"+data2Normalized);
		System.out.println("data3Normalized: "+data3Normalized.size()+ ">>>"+data3Normalized);
		System.out.println("data4Normalized: "+data4Normalized.size()+ ">>>"+data4Normalized);
		System.out.println("data5Normalized: "+data5Normalized.size()+ ">>>"+data5Normalized);
		System.out.println("data6Normalized: "+data6Normalized.size()+ ">>>"+data6Normalized);
		System.out.println("data7Normalized: "+data7Normalized.size()+ ">>>"+data7Normalized);
		System.out.println("data8Normalized: "+data8Normalized.size()+ ">>>"+data8Normalized);
		System.out.println("");
		String output = "";
		for (int i = 0; i < data0Normalized.size(); i++)
		{
			output += data0Normalized.get(i) + "," + data1Normalized.get(i) + "," 
					+ data2Normalized.get(i) + "," + data3Normalized.get(i) + ","
					+ data4Normalized.get(i) + "," + data5Normalized.get(i) + ","
					+ data6Normalized.get(i) + "," + data7Normalized.get(i) + ","
					+ data8Normalized.get(i)
					+ "\n";

		}
		

		String output2 = "";
		output2 += "@relation production-data";
		output2 += "\n";
		output2 += "@attribute requestor_nationality numeric";
		output2 += "\n";
		output2 += "@attribute requestor_gender numeric";
		output2 += "\n";
		output2 += "@attribute no_of_respondent numeric";
		output2 += "\n";
		output2 += "@attribute respondent_nationality numeric";
		output2 += "\n";
		output2 += "@attribute shift numeric";
		output2 += "\n";
		output2 += "@attribute nickname_type numeric";
		output2 += "\n";
		output2 += "@attribute problem numeric";
		output2 += "\n";
		output2 += "@attribute downtime numeric";
		output2 += "\n";
		output2 += "@attribute solvetime numeric";
		output2 += "\n";
		output2 += "@data";
		output2 += "\n";

		System.out.println(output2 + output);
		
		FileWriter fw = null;
		try
		{
			fw = new FileWriter(filename, false);
			fw.write(output2);
			fw.write(output);
			fw.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		fw = null;

	}


	
	
	List<Integer> data0 = new ArrayList<Integer>(); // requestor_nationality
	List<Integer> data1 = new ArrayList<Integer>(); // requestor_gender
	List<Integer> data2 = new ArrayList<Integer>(); // no_of_respondent
	List<Integer> data3 = new ArrayList<Integer>(); // respondent_nationality
	List<Integer> data4 = new ArrayList<Integer>(); // shift
	List<Integer> data5 = new ArrayList<Integer>(); // nickname_type
	List<Integer> data6 = new ArrayList<Integer>(); // problem
	List<Integer> data7 = new ArrayList<Integer>(); // downtime
	List<Integer> data8 = new ArrayList<Integer>(); // solvetime
	
	List<Double> data0Normalized = new ArrayList<Double>(); // requestor_nationality
	List<Double> data1Normalized = new ArrayList<Double>(); // requestor_gender
	List<Double> data2Normalized = new ArrayList<Double>(); // no_of_respondent
	List<Double> data3Normalized = new ArrayList<Double>(); // respondent_nationality
	List<Double> data4Normalized = new ArrayList<Double>(); // shift
	List<Double> data5Normalized = new ArrayList<Double>(); // nickname_type
	List<Double> data6Normalized = new ArrayList<Double>(); // problem
	List<Double> data7Normalized = new ArrayList<Double>(); // downtime
	List<Double> data8Normalized = new ArrayList<Double>(); // solvetime
	
	int[] data0Bound = new int[2];
	int[] data1Bound = new int[2];
	int[] data2Bound = new int[2];
	int[] data3Bound = new int[2];
	int[] data4Bound = new int[2];
	int[] data5Bound = new int[2];
	int[] data6Bound = new int[2];
	int[] data7Bound = new int[2];
	int[] data8Bound = new int[2];

	Set<Double> uniqueProblem = new HashSet<Double>();

	public void doIt(String filename) throws IOException

	{
		data0Bound[0] = Integer.MAX_VALUE;
		data1Bound[0] = Integer.MAX_VALUE;
		data2Bound[0] = Integer.MAX_VALUE;
		data3Bound[0] = Integer.MAX_VALUE;
		data4Bound[0] = Integer.MAX_VALUE;
		data5Bound[0] = Integer.MAX_VALUE;
		data6Bound[0] = Integer.MAX_VALUE;
		data7Bound[0] = Integer.MAX_VALUE;
		data8Bound[0] = Integer.MAX_VALUE;
		
		data0Bound[1] = Integer.MIN_VALUE;
		data1Bound[1] = Integer.MIN_VALUE;
		data2Bound[1] = Integer.MIN_VALUE;
		data3Bound[1] = Integer.MIN_VALUE;
		data4Bound[1] = Integer.MIN_VALUE;
		data5Bound[1] = Integer.MIN_VALUE;
		data6Bound[1] = Integer.MIN_VALUE;
		data7Bound[1] = Integer.MIN_VALUE;
		data8Bound[1] = Integer.MIN_VALUE;
		
		int count = 0;
		List<String> code = null;
		List<String> name = null;
		String[] nextTrueLine = null;
		CSVReader reader = new CSVReader(new FileReader(filename),
				',');

		while ((nextTrueLine = reader.readNext()) != null)
		{
			for (int i = 0; i < nextTrueLine.length; i++)
			{
				String temp = nextTrueLine[i].trim();
				int bb = Integer.valueOf(temp);
				if (i == 0) 
				{
					data0.add(bb);
					if (bb < data0Bound[0])
						data0Bound[0] = bb;
					if (bb > data0Bound[1])
						data0Bound[1] = bb;
				}
				else if (i == 1)
				{
					data1.add(bb);
					if (bb < data1Bound[0])
						data1Bound[0] = bb;
					if (bb > data1Bound[1])
						data1Bound[1] = bb;
				}
				else if (i == 2)
				{
					data2.add(bb);
					if (bb < data2Bound[0])
						data2Bound[0] = bb;
					if (bb > data2Bound[1])
						data2Bound[1] = bb;
				}
				else if (i == 3)
				{
					data3.add(bb);
					if (bb < data3Bound[0])
						data3Bound[0] = bb;
					if (bb > data3Bound[1])
						data3Bound[1] = bb;
				}
				else if (i == 4)
				{
					data4.add(bb);
					if (bb < data4Bound[0])
						data4Bound[0] = bb;
					if (bb > data4Bound[1])
						data4Bound[1] = bb;
				}
				else if (i == 5)
				{
					data5.add(bb);
					if (bb < data5Bound[0])
						data5Bound[0] = bb;
					if (bb > data5Bound[1])
						data5Bound[1] = bb;
				}
				else if (i == 6)
				{
					data6.add(bb);
					if (bb < data6Bound[0])
						data6Bound[0] = bb;
					if (bb > data6Bound[1])
						data6Bound[1] = bb;
				}
				else if (i == 7)
				{
					data7.add(bb);
					if (bb < data7Bound[0])
						data7Bound[0] = bb;
					if (bb > data7Bound[1])
						data7Bound[1] = bb;
				}
				else if (i == 8)
				{
					data8.add(bb);
					if (bb < data8Bound[0])
						data8Bound[0] = bb;
					if (bb > data8Bound[1])
						data8Bound[1] = bb;
				}
			}
		}

		reader.close();
		reader = null;

	}
	
	public void normalizeData()
	{
		double temp = 0d;
		BigDecimal bd = new BigDecimal(0);
		BigDecimal bd2 = new BigDecimal(0);
		for (int i = 0; i < data0.size(); i++)
		{

				temp = data0.get(i) - data0Bound[0];
				bd2 = new BigDecimal(temp);
				if (data0Bound[1] != data0.get(i))
					bd = new BigDecimal(data0Bound[1] - data0Bound[0]);
				else
					bd = new BigDecimal(data0Bound[1]);
				bd = bd2.divide(bd, MathContext.DECIMAL64);
				temp = bd.doubleValue();
				data0Normalized.add(temp);


				temp = data1.get(i) - data1Bound[0];
				bd2 = new BigDecimal(temp);
				if (data1Bound[1] != data1.get(i))
					bd = new BigDecimal(data1Bound[1] - data1Bound[0]);
				else
					bd = new BigDecimal(data1Bound[1]);
				bd = bd2.divide(bd, MathContext.DECIMAL64);
				temp = bd.doubleValue();
				data1Normalized.add(temp);

				temp = data2.get(i) - data2Bound[0];
				bd2 = new BigDecimal(temp);
				if (data2Bound[1] != data2.get(i))
					bd = new BigDecimal(data2Bound[1] - data2Bound[0]);
				else
					bd = new BigDecimal(data2Bound[1]);
				bd = bd2.divide(bd, MathContext.DECIMAL64);
				temp = bd.doubleValue();
				data2Normalized.add(temp);

				temp = data3.get(i) - data3Bound[0];
				bd2 = new BigDecimal(temp);
				if (data3Bound[1] != data3.get(i))
					bd = new BigDecimal(data3Bound[1] - data3Bound[0]);
				else
					bd = new BigDecimal(data3Bound[1]);
				bd = bd2.divide(bd, MathContext.DECIMAL64);
				temp = bd.doubleValue();
				data3Normalized.add(temp);

				temp = data4.get(i) - data4Bound[0];
				bd2 = new BigDecimal(temp);
				if (data4Bound[1] != data4.get(i))
					bd = new BigDecimal(data4Bound[1] - data4Bound[0]);
				else
					bd = new BigDecimal(data4Bound[1]);
				bd = bd2.divide(bd, MathContext.DECIMAL64);
				temp = bd.doubleValue();
				data4Normalized.add(temp);

				temp = data5.get(i) - data5Bound[0];
				bd2 = new BigDecimal(temp);
				if (data5Bound[1] != data5.get(i))
					bd = new BigDecimal(data5Bound[1] - data5Bound[0]);
				else
					bd = new BigDecimal(data5Bound[1]);
				bd = bd2.divide(bd, MathContext.DECIMAL64);
				temp = bd.doubleValue();
				data5Normalized.add(temp);

				temp = data6.get(i) - data6Bound[0];
				bd2 = new BigDecimal(temp);
				if (data6Bound[1] != data6.get(i))
					bd = new BigDecimal(data6Bound[1] - data6Bound[0]);
				else
					bd = new BigDecimal(data6Bound[1]);
				bd = bd2.divide(bd, MathContext.DECIMAL64);
				temp = bd.doubleValue();
				data6Normalized.add(temp);
				uniqueProblem.add(temp);

				temp = data7.get(i) - data7Bound[0];
				bd2 = new BigDecimal(temp);
				if (data7Bound[1] != data7.get(i))
					bd = new BigDecimal(data7Bound[1] - data7Bound[0]);
				else
					bd = new BigDecimal(data7Bound[1]);
				bd = bd2.divide(bd, MathContext.DECIMAL64);
				temp = bd.doubleValue();
				data7Normalized.add(temp);

				temp = data8.get(i) - data8Bound[0];
				bd2 = new BigDecimal(temp);
				if (data8Bound[1] != data8.get(i))
					bd = new BigDecimal(data8Bound[1] - data8Bound[0]);
				else
					bd = new BigDecimal(data8Bound[1]);
				bd = bd2.divide(bd, MathContext.DECIMAL64);
				temp = bd.doubleValue();
				data8Normalized.add(temp);

		}
		
	}

}
