package weichien;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Random;
import java.util.Vector;

import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;

import weka.attributeSelection.PrincipalComponents;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.LibSVM;
import weka.classifiers.functions.Logistic;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.classifiers.functions.RBFNetwork;
import weka.classifiers.functions.SMO;
import weka.classifiers.functions.SimpleLogistic;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.adtree.ReferenceInstances;
import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.UnsupervisedFilter;
import weka.filters.unsupervised.attribute.Normalize;
import weka.filters.unsupervised.attribute.Wavelet;

public class ClassificationExp
{
	private static final String version = "ver1";

	public final String preProcessFilter = "weka.filters.unsupervised.attribute.PrincipalComponents";


	// public final String classfierFilter2 =
	// "weka.filters.unsupervised.instance.Randomize";
	public final String classfierFilter0 = "weka.filters.unsupervised.attribute.PrincipalComponents";
	public final String classfierFilter1 = "weka.filters.unsupervised.attribute.Wavelet";
	public final String classfierFilter2 = "weka.filters.unsupervised.attribute.Normalize";
	ReferenceInstances tInst_local = null;
	ReferenceInstances pInst_local = null;
	boolean debug = false;
	public boolean MANUAL = false;
	public String mdsType = null;

	// for moea use
	WekaResult wekaResult = null;

	public void training(int classType, String filename) throws Exception
	{

		String status = "";
		if (filename == null)
			status = "Training " + trainFile + ", testing " + testFile + " with ";
		else
			status = "Training " + filename + " with ";

		// choosing which classifier to be use
		Classifier classifier = null;
		if (classType == 0)
		{
			classifier = new MultilayerPerceptron();
			status += "MultilayerPerceptron";
		}
		else if (classType == 1)
		{
			classifier = new Logistic();
			status += "Logistic";
		}
		else if (classType == 2)
		{
			classifier = new RBFNetwork();
			status += "RBFNetwork";
		}
		else if (classType == 3)
		{
			classifier = new SMO();
			status += "SMO";
		}
		else if (classType == 4)
		{
			classifier = new SimpleLogistic();
			status += "SimpleLogistic";
		}
		else if (classType == 5)
		{
			String[] options = new String[13];
			options[0] = "s 0"; // param.svm_type; 0=C_SVC
			options[1] = "t 2"; // param.kernel_type; 2=RBF
			options[2] = "d 3"; // param.degree
			options[3] = "g 0"; // param.gamma
			options[4] = "r 0"; // param.coef0
			options[5] = "n 0.5"; // param.nu
			options[6] = "m 100"; // param.cache_size
			options[7] = "c 100"; // param.C
			options[8] = "e 1e-3"; // param.eps
			options[9] = "p 0.1"; // param.p
			options[10] = "h 0"; // param.shrinking
			options[11] = "b 0"; // param.probability
			options[12] = "w 0 0"; // param.probability
			classifier = new LibSVM();
			((LibSVM) classifier).setCost(100d);// param.C
			status += "LibSVM";
		}
		else if (classType == 6)
		{
			classifier = new J48();
			status += "J48 (known as C4.5)";
		}

		Vector<String[]> filterOptions = new Vector<String[]>();
		/** the training instances */
		// Instances m_Training = null;
		/** the filter to use */
		Filter m_Filter = null;
		/** for evaluating the classifier */
		Evaluation m_Evaluation = null;
		// set filter

		m_Filter = (Filter) Class.forName(classfierFilter2).newInstance();
		((Normalize) m_Filter).setOptions(filterOptions.toArray(new String[filterOptions.size()]));
		status += ", filtering with Normalize";

		weka.core.Instances filtered = null;
		weka.core.Instances filteredT = null;
		// set training
		Instances m_Training = null;
		Instances m_Test = null;
		Instances inst = null;
		Instances inst2 = null;
		String NEXT = null;

		status += ", with CrossValidation";
		BufferedReader reader2 = new BufferedReader(new FileReader(filename));
		m_Training = new Instances(reader2);
		m_Training.setClassIndex(m_Training.numAttributes() - 1);
		status += "\nInput for training... " + m_Training.toSummaryString();

		// Normalize norm = new Normalize();
		// norm.setInputFormat(m_Training);
		// Instances processed_train = Filter.useFilter(m_Training, norm);

		// m_Filter.setInputFormat(m_Training);
		// filtered = weka.filters.Filter.useFilter(m_Training, m_Filter);

		PrincipalComponents pca = new PrincipalComponents();
		pca.setMaximumAttributeNames(-1);
		pca.buildEvaluator(m_Training);
		Instances newData = pca.transformedData(m_Training);

		System.out.println("numAtt: " + m_Training.numAttributes() + " --> " + +newData.numAttributes());

		
		// randomize data
		Random rand = new Random(System.currentTimeMillis());
		rand = new Random(123);
		Instances randData = new Instances(newData);
		randData.randomize(rand);
		if (randData.classAttribute().isNominal())
			randData.stratify(folds);

		// perform cross-validation
		m_Evaluation = new Evaluation(randData);
		DescriptiveStatistics ds = new DescriptiveStatistics();
		Instances train = null, test = null;
		for (int n = 0; n < folds; n++)
		{
			train = randData.trainCV(folds, n, rand);
			test = randData.testCV(folds, n);
			// the above code is used by the StratifiedRemoveFolds filter, the
			// code below by the Explorer/Experimenter:
			// Instances train = randData.trainCV(folds, n, rand);

			// build and evaluate classifier
			Classifier clsCopy = Classifier.makeCopy(classifier);
			clsCopy.buildClassifier(train);
			m_Evaluation.evaluateModel(clsCopy, test);
			m_Evaluation.crossValidateModel(classifier, train, folds, rand);
			wekaResult = new WekaResult(m_Evaluation.truePositiveRate(0), m_Evaluation.trueNegativeRate(0),
					m_Evaluation.falsePositiveRate(0), m_Evaluation.falseNegativeRate(0));
			double accuracy = wekaResult.accuracy();
			ds.addValue(accuracy);
			System.out.println(n + ": " + accuracy);
		}
		System.out.println("mean of accuracy " + ds.getMean());

		// build and evaluate classifier
		// Classifier clsCopy = Classifier.makeCopy(classifier);
		// clsCopy.buildClassifier(randData);
		// m_Evaluation.crossValidateModel(classifier, randData, folds, rand);

		// filtered = m_Training;
		// train classifier on complete file for tree
		// classifier.buildClassifier(filtered);
		// 10fold CV with seed=123
		m_Evaluation = new Evaluation(randData);
		m_Evaluation.crossValidateModel(classifier, randData, folds, rand);

		reader2.close();
		reader2 = null;

		if (debug)
		{
			// toString(classifier, m_Filter, m_Training, m_Evaluation);
			System.out.println(m_Evaluation.toSummaryString("\nResults\n======\n", false));
			System.out.println(m_Evaluation.toMatrixString());
		}

		// System.out.println("\tTP,TN,FP,FN=" +
		// m_Evaluation.truePositiveRate(0)
		// + ", " + m_Evaluation.trueNegativeRate(0) + ", "
		// + m_Evaluation.falsePositiveRate(0) + ", "
		// + m_Evaluation.falseNegativeRate(0));
		// System.out.println("\tTP,TN,FP,FN===" +
		// m_Evaluation.truePositiveRate(1)
		// + ", " + m_Evaluation.trueNegativeRate(1) + ", "
		// + m_Evaluation.falsePositiveRate(1) + ", "
		// + m_Evaluation.falseNegativeRate(1));
		// System.out.println(status);
		double sensi = 0d, speci = 0d, accuracy = 0d;
		wekaResult = new WekaResult(m_Evaluation.truePositiveRate(0), m_Evaluation.trueNegativeRate(0),
				m_Evaluation.falsePositiveRate(0), m_Evaluation.falseNegativeRate(0));
		sensi = -1d; // wekaResult.sensitivity();
		speci = -1d; // wekaResult.specificity();
		accuracy = wekaResult.accuracy();
		if (debug)
			System.out.println(m_Evaluation.toClassDetailsString());
		// System.out.println("weka\t::: specificity sensitivity accuracy = " +
		// speci
		// + " " + sensi + " " + accuracy);
		System.out.println("weka\t::: accuracy = " + accuracy);

		m_Evaluation = null;
		if (MANUAL && testFile != null)
		{
			File f = new File(testFile);
			if (f.exists())
				f.delete();
			f = null;
		}

		if (debug)
			System.out.println("Training finished!");
	}

	public void training(int filtype, int classType, int eType, String filename) throws Exception
	{

		String status = "";
		if (filename == null)
			status = "Training " + trainFile + ", testing " + testFile + " with ";
		else
			status = "Training " + filename + " with ";

		// choosing which classifier to be use
		Classifier classifier = null;
		if (classType == 0)
		{
			classifier = new MultilayerPerceptron();
			status += "MultilayerPerceptron";
		}
		else if (classType == 1)
		{
			classifier = new Logistic();
			status += "Logistic";
		}
		else if (classType == 2)
		{
			classifier = new RBFNetwork();
			status += "RBFNetwork";
		}
		else if (classType == 3)
		{
			classifier = new SMO();
			status += "SMO";
		}
		else if (classType == 4)
		{
			classifier = new SimpleLogistic();
			status += "SimpleLogistic";
		}
		else if (classType == 5)
		{
			String[] options = new String[13];
			options[0] = "s 0"; // param.svm_type; 0=C_SVC
			options[1] = "t 2"; // param.kernel_type; 2=RBF
			options[2] = "d 3"; // param.degree
			options[3] = "g 0"; // param.gamma
			options[4] = "r 0"; // param.coef0
			options[5] = "n 0.5"; // param.nu
			options[6] = "m 100"; // param.cache_size
			options[7] = "c 100"; // param.C
			options[8] = "e 1e-3"; // param.eps
			options[9] = "p 0.1"; // param.p
			options[10] = "h 0"; // param.shrinking
			options[11] = "b 0"; // param.probability
			options[12] = "w 0 0"; // param.probability
			classifier = new LibSVM();
			((LibSVM) classifier).setCost(100d);// param.C
			status += "LibSVM";
		}
		else if (classType == 6)
		{
			classifier = new J48();
			status += "J48 (known as C4.5)";
		}

		Vector<String[]> filterOptions = new Vector<String[]>();
		/** the training instances */
		// Instances m_Training = null;
		/** the filter to use */
		Filter m_Filter = null;
		/** for evaluating the classifier */
		Evaluation m_Evaluation = null;
		// set filter

		if (filtype != 2)
		{

			if (filtype == 0)
			{
				m_Filter = (Filter) Class.forName(classfierFilter0).newInstance();
			}
			else if (filtype == 1)
			{
				m_Filter = (Filter) Class.forName(classfierFilter1).newInstance();
			}
			else if (filtype == 3)
			{
				m_Filter = (Filter) Class.forName(classfierFilter2).newInstance();
			}
			// set filter using PCA approach
			// reference: Mark Hall and Gabi Schmidberger (?).
			// PrincipalComponents
			if (filtype == 0)
			{
				// if (m_Filter instanceof UnsupervisedFilter)
				// ((PrincipalComponents) m_Filter).setOptions(filterOptions
				// .toArray(new String[filterOptions.size()]));
				// status += ", filtering with PrincipalComponents";
			}
			// set filter using Wavelet approach
			// reference: Kristian Sandberg (2000). The Haar wavelet transform.
			else if (filtype == 1)
			{
				if (m_Filter instanceof UnsupervisedFilter)
					((Wavelet) m_Filter).setOptions(filterOptions.toArray(new String[filterOptions.size()]));
				status += ", filtering with Wavelet";
			}
			else if (filtype == 3)
			{
				if (m_Filter instanceof UnsupervisedFilter)
					((Normalize) m_Filter).setOptions(filterOptions.toArray(new String[filterOptions.size()]));
				status += ", filtering with Normalize";
			}

		}
		weka.core.Instances filtered = null;
		weka.core.Instances filteredT = null;
		// set training
		Instances m_Training = null;
		Instances m_Test = null;
		Instances inst = null;
		Instances inst2 = null;
		String NEXT = null;
		if (eType == 0)
		{

			if (MANUAL) // use different train & test file
			{
				inst = new Instances(new BufferedReader(new FileReader(trainFile)));
				tInst_local = new ReferenceInstances(inst, 0);
				Enumeration<Instance> eInst = inst.enumerateInstances();
				while (eInst.hasMoreElements())
				{
					Instance a = (Instance) eInst.nextElement();
					tInst_local.add(a);
				}

				inst2 = new Instances(new BufferedReader(new FileReader(testFile)));
				pInst_local = new ReferenceInstances(inst2, 0);
				Enumeration<Instance> eInst2 = inst2.enumerateInstances();
				while (eInst2.hasMoreElements())
				{
					Instance a = (Instance) eInst2.nextElement();
					pInst_local.add(a);
				}

				tInst_local.setClassIndex(tInst_local.numAttributes() - 1);
				pInst_local.setClassIndex(pInst_local.numAttributes() - 1);
			}
			else
			{
				int row = 0;
				BufferedReader reader = new BufferedReader(new FileReader(filename));
				while ((NEXT = reader.readLine()) != null)
					row++;
				reader.close();
				reader = null;

				// percentage split
				status += ", with PercentageSplit 67:33";
				randomizedData(((row / 3) * 2), (row / 3), filename);
				tInst_local.setClassIndex(tInst_local.numAttributes() - 1);
				pInst_local.setClassIndex(pInst_local.numAttributes() - 1);
				status += "\nInput for training... " + tInst_local.toSummaryString();
				System.out.println(status);
			}

			// run/apply filter
			if (filtype != 2)
			{
				Instances allInst = new Instances(inst);
				Enumeration<Instance> e = inst2.enumerateInstances();
				while (e.hasMoreElements())
					allInst.add(e.nextElement());
				allInst.setClassIndex(allInst.numAttributes() - 1);

				m_Filter.setInputFormat(allInst);
				filtered = weka.filters.Filter.useFilter(tInst_local, m_Filter);
				filteredT = weka.filters.Filter.useFilter(pInst_local, m_Filter);
				allInst = null;
				e = null;
			}
			else
			{
				filtered = tInst_local;
				filteredT = pInst_local;
			}

			classifier.buildClassifier(filtered);
			m_Evaluation = new Evaluation(filtered);
			m_Evaluation.evaluateModel(classifier, filteredT);
		}
		else if (eType == 1)
		{
			status += ", with CrossValidation";
			BufferedReader reader2 = new BufferedReader(new FileReader(filename));
			m_Training = new Instances(reader2);
			m_Training.setClassIndex(m_Training.numAttributes() - 1);
			status += "\nInput for training... " + m_Training.toSummaryString();

			// run filter
			if (filtype != 2)
			{
				m_Filter.setInputFormat(m_Training);
				filtered = weka.filters.Filter.useFilter(m_Training, m_Filter);
			}
			else
				filtered = m_Training;
			// train classifier on complete file for tree
			classifier.buildClassifier(filtered);

			// 10fold CV with seed=123
			m_Evaluation = new Evaluation(filtered);
			m_Evaluation.crossValidateModel(classifier, filtered, 10, new Random(123));

			reader2.close();
			reader2 = null;
		}
		if (debug)
		{
			// toString(classifier, m_Filter, m_Training, m_Evaluation);
			System.out.println(m_Evaluation.toSummaryString("\nResults\n======\n", false));
			System.out.println(m_Evaluation.toMatrixString());
		}

		// System.out.println("\tTP,TN,FP,FN=" +
		// m_Evaluation.truePositiveRate(0)
		// + ", " + m_Evaluation.trueNegativeRate(0) + ", "
		// + m_Evaluation.falsePositiveRate(0) + ", "
		// + m_Evaluation.falseNegativeRate(0));
		// System.out.println("\tTP,TN,FP,FN===" +
		// m_Evaluation.truePositiveRate(1)
		// + ", " + m_Evaluation.trueNegativeRate(1) + ", "
		// + m_Evaluation.falsePositiveRate(1) + ", "
		// + m_Evaluation.falseNegativeRate(1));
		// System.out.println(status);
		double sensi = 0d, speci = 0d, accuracy = 0d;
		wekaResult = new WekaResult(m_Evaluation.truePositiveRate(0), m_Evaluation.trueNegativeRate(0),
				m_Evaluation.falsePositiveRate(0), m_Evaluation.falseNegativeRate(0));
		sensi = -1d; // wekaResult.sensitivity();
		speci = -1d; // wekaResult.specificity();
		accuracy = wekaResult.accuracy();
		if (debug)
			System.out.println(m_Evaluation.toClassDetailsString());
		// System.out.println("weka\t::: specificity sensitivity accuracy = " +
		// speci
		// + " " + sensi + " " + accuracy);
		System.out.println("weka\t::: accuracy = " + accuracy);

		m_Evaluation = null;
		if (MANUAL && testFile != null)
		{
			File f = new File(testFile);
			if (f.exists())
				f.delete();
			f = null;
		}

		if (debug)
			System.out.println("Training finished!");
	}

	public WekaResult getWekaResult()
	{
		return wekaResult;
	}

	public void toString(Classifier m_Classifier, Filter m_Filter, Instances m_Training, Evaluation m_Evaluation)
	{
		StringBuffer result;

		result = new StringBuffer();
		result.append("on " + new Date() + "\n");

		result.append(m_Classifier.toString() + "\n");
		result.append(m_Evaluation.toSummaryString() + "\n");
		try
		{
			result.append(m_Evaluation.toMatrixString() + "\n");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		try
		{
			result.append(m_Evaluation.toClassDetailsString() + "\n");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		System.out.println(result.toString());
	}

	private void randomizedData(int trainingSize, int predictingSize, String FILENAME) throws Exception
	{
		// randomize the position
		List<Integer> tData = new ArrayList<Integer>();
		List<Integer> pData = new ArrayList<Integer>();
		Random r = new Random(123);
		int position = 0;
		while (true)
		{
			// random one new position
			position = r.nextInt(trainingSize + predictingSize);
			// make sure size max is not reach, position is not repeating
			if (tData.size() < trainingSize && !tData.contains(position) && !pData.contains(position))
				tData.add(position);
			// random one new position
			position = r.nextInt(trainingSize + predictingSize);
			// make sure size max is not reach, position is not repeating
			if (pData.size() < predictingSize && !tData.contains(position) && !pData.contains(position))
				pData.add(position);

			if (tData.size() >= trainingSize && pData.size() >= predictingSize)
				break;
		}
		// System.out.println("Unique position from randomization");
		// System.out.println("tData size " + tData.size() + ": " + tData);
		// System.out.println("pData size " + pData.size() + ": " + pData);

		// Adopting randomize position
		// and form 2 instances for training and predicting
		Instances inst = null;
		inst = new Instances(new BufferedReader(new FileReader(FILENAME)));
		int attCount = inst.numAttributes();
		tInst_local = new ReferenceInstances(inst, 0);
		pInst_local = new ReferenceInstances(inst, 0);

		// retrieve attribute's name
		position = 0;
		Enumeration<Attribute> eInst2 = inst.enumerateAttributes();
		Attribute[] attList = new Attribute[attCount];
		while (eInst2.hasMoreElements())
		{
			Attribute a = (Attribute) eInst2.nextElement();
			attList[position] = a;
			position++;
		}
		// retrieve attribute's value
		position = 0;
		Enumeration<Instance> eInst = inst.enumerateInstances();
		while (eInst.hasMoreElements())
		{
			Instance a = (Instance) eInst.nextElement();
			if (tData.contains(position))
				tInst_local.add(a);
			if (pData.contains(position))
				pInst_local.add(a);
			position++;
		}
		System.out.println("Actual values with adopting randomization position");
		// System.out.println("Training instances\n" + tInst_local.toString());
		System.out.println("\n=================================================\n");
		// System.out.println("Predicting instances\n" +
		// pInst_local.toString());
		System.out.println("\n=================================================\n");
	}

	public static void main(String[] args) throws Exception
	{
		// WekaBio b = new WekaBio();
		// b.getGoodMean(WekaBio.PIMA);
		// System.exit(1);

		// MmGA produce array chromo
		// submit to classifier
		// classifier load stat.csv to determine the feature (array chromo)
		// obtain classifier's results (accuracy, etc)
		// feedback to MmGA with values
		// 1. 1-(correct/(correct+incorrect+unclassified)) : lower better
		// 2. falsePositiveRate : lower better
		// 3. falseNegativeRate : lower better

		ClassificationExp m = new ClassificationExp();
		m.scenarioWOU();
	}

	private String trainFile = "";
	private String testFile = "";
	private int folds = 10;

	public void scenarioWOU() throws Exception
	{
		MANUAL = false;
		
		//hey wei chien!
		Random rd = new Random (System.currentTimeMillis());
		int seedNum = rd.nextInt();
		
		Prepros4 myObj = new Prepros4();
		myObj.doIt("data2/Sample master data_3.csv");
		myObj.normalizeData();
		String fileName = "log/withclass_"+System.currentTimeMillis()+".arff";
		myObj.prepareARFF_with_class(fileName);
		
		System.out.println("Using seed number "+ seedNum);
		
		for (int t = 0; t < 5; t++)
		{
			debug = true;
			

			// Classification
			// cross(a, b, c, fileName)
			// Filter (Ftype): a: 0=PCA, 1=Wavelet, 2=none
			// Classifier (CType): b: 0=MLP, 1=Logistic, 2=RBFNetwork, 3=SMO,
			// 4=SimpleLogistic, 5=LibSVM, 6=J48
			// Evualtion (Etype): c: 0=Percentage Split, 1=crossValidate
			if (t == 10)
			{
				//System.out.println("==========MLP=========with no filter and with crossValidate");
				//fileName = prepareFile(inputDataFile, chromo, "log/" + version, "MLP.arff");
				//training(0, fileName);
			}
			if (t == 1)
			{
				System.out.println("==========Logistic=========with no filter and with crossValidate");
				//fileName = prepareFile(inputDataFile, chromo, "log/" + version, "Logistic.arff");
				training(1, fileName);
			}
			if (t == 2)
			{
				//System.out.println("==========RBF=========with no filter and with crossValidate");
				//fileName = prepareFile(inputDataFile, chromo, "log/" + version, "RBF.arff");
				//training(2, fileName);
			}
			if (t == 3)
			{
				System.out.println("==========SVM=========with no filter and with crossValidate");
				//fileName = prepareFile(inputDataFile, chromo, "log/" + version, "SVM.arff");
				training(5, fileName);
			}
			if (t == 4)
			{
				//System.out.println("==========J48=========with no filter and with crossValidate");
				//fileName = prepareFile(inputDataFile, chromo, "log/" + version, "J48.arff");
				//training(6, fileName);
			}

		
		}
	}




	public void deleteFile(String fileWithPath)
	{
		try
		{
			File f = new File(fileWithPath);
			if (f.isFile())
				f.delete();
			f = null;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}

class MyData2
{
	MyData2(double[] meanInput, double[] minInput, double[] maxInput)
	{
		this.mean = meanInput;
		this.min = minInput;
		this.max = maxInput;
	}

	double[] mean = null;
	double[] min = null;
	double[] max = null;

	public String toString()
	{
		String result = "";
		for (int i = 0; mean != null && i < mean.length; i++)
			result += mean[i] + " ";
		result += "\n";
		for (int i = 0; min != null && i < min.length; i++)
			result += min[i] + " ";
		result += "\n";
		for (int i = 0; max != null && i < max.length; i++)
			result += max[i] + " ";
		result += "\n";
		return result;

	}
}